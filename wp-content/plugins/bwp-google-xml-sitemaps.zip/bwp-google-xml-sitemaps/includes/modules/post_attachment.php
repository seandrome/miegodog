<?php
	echo 'Intentionally left blank.';
	exit;
?>