=== Auto Ping Booster ===
Contributors: same2cool
Tags: SEO, Ping, Google, Blogsearch, Booster, Auto Ping
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: SEO, Ping
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Auto Ping Booster will auto Ping your blog in Google Blogsearch after every update.

== Description ==

Use this plugin to ping your blog, post, pages, images, docs files, on daily basis.
Auto Ping Booster will auto Ping your blog in Google Blogsearch after every update.
Auto Ping Booster is known about SEO Booster. 
Just upload auto-ping-booster.zip file to plugin directory or upload it by plugin option in menu and active it. It works automatically itself.

== Installation ==

1. Upload `auto-ping-booster.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.
How does this plugin work?
This plugin ping your blog to Google blog search on each update.